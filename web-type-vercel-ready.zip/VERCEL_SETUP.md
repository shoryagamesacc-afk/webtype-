
# Web Type — Vercel-ready project

## Local
```bash
npm install
npm run dev
```

## Production build
```bash
npm run build
npm start
```

## Vercel
1. Upload the contents of this folder (or connect the Git repository).
2. Set Framework Preset to **Next.js**.
3. Keep Root Directory as `./`.
4. Leave Build/Output/Install/Development overrides OFF so Vercel auto-detects Next.js.
5. Deploy.

The project uses the standard Next.js build output; it does not use `output: "export"`.
